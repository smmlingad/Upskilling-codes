public class sample {
    public static void main (String[] args) {
        System.out.println("Minutes per day:" + 24 * 60);
        System.out.println("Seconds per day:" + 24 * 60 * 60);
        System.out.println("Modulo of 5:" + 5 % 2);
        int arr[] = {1, 2, 3, 4};
        for (int i = 0; i < arr.length; i++) {
            System.out.println("Element at index " + i +
                    " : " + arr[i]);

            public static void main (String[]args){
                int arrayN[] = {1, 2, 3, 4};
                changeArrayElement(arrayN);
            for (int i = 0; i < arrayN.length; i++) {
        System.out.println(arrayN[i]);
    }
            }
        }
    }
         public static void changeArrayElement(int myArray[]){
            myArray[1] = 100;
            }


        }
    }
}
