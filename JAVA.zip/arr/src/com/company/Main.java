package com.company;

public class Main {

    public static void main(String[] args) {
    int arrayN[] = {1, 2, 3, 4};

        changeArray(arrayN);

        for (int i = 0; i < arrayN.length; i++) {
            System.out.println(arrayN[i]);
        }
    }

    static void changeArray(int array1[]) {
        array1[2] = 50;
    }
}